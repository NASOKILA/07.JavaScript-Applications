


/*
    Ako pravim primerno single page app
    mojem da polzvame 'windiw' kato kesh pamet.
    mojem da mu zakachame neshta i posle esno da gi durpame.
    
    
    VMESTO DA SI IGRAEM SUS display: none;  i display: block;
    MOJEM DA POLZVAME OT JQUERY: 
        .show()
        .hide()
        .toggle()  //PRAVI I DVETE, AKO E display:none; go pravi na display:block;  i obratnoto.

    
    //VAJNO !!!
    // Vmesto $(this).parent().find('...'); 
    //mojem da polzvame .next();

*/



